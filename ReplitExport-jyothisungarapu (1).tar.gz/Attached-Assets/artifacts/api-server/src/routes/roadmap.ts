import { Router, type IRouter } from "express";
import { GenerateRoadmapBody } from "@workspace/api-zod";
import { openai } from "@workspace/integrations-openai-ai-server";
import { generateImageBuffer } from "@workspace/integrations-openai-ai-server/image";

const router: IRouter = Router();

const DOMAIN_IMAGE_PROMPTS: Record<string, string> = {
  "software engineering": "A breathtaking futuristic digital landscape: glowing code streams flow through a neon-lit cityscape, floating holographic screens display elegant algorithms, purple and cyan light trails weave between skyscrapers, isometric perspective, ultra-detailed, cinematic 4K, dark background with vibrant neon accents",
  "data science": "A stunning visualization of neural networks and data: glowing nodes connected by flowing light streams, 3D bar charts and scatter plots floating in dark space, DNA helix entwined with data cables, gradient from deep blue to purple, ultra-detailed, photorealistic, cinematic lighting",
  "ux/ui design": "A gorgeous creative design workspace: vibrant app mockups floating in 3D space, color palettes exploding like fireworks, a stylus tracing glowing wireframes on a dark canvas, elegant typography samples orbiting around, neon pink and purple palette, cinematic depth of field, ultra-detailed",
  "digital marketing": "A dynamic digital marketing visualization: glowing social media icons connected by pulsing light networks, rising analytics graphs with neon glow, satellite dish beaming data across continents, vibrant orange and yellow gradients on dark background, ultra-detailed, cinematic",
  "finance & ca": "An elegant financial visualization: golden coins and rupee symbols floating in precise formations, holographic stock charts with green upward trends, a majestic courthouse pillared with light beams representing law, deep navy background with gold and emerald accents, photorealistic, ultra-detailed",
  "medicine / mbbs": "A majestic medical technology scene: glowing DNA strands intertwined with medical cross symbols, transparent human anatomy overlaid with diagnostic data, pills and molecules orbiting a glowing caduceus, sterile white and electric blue on dark background, photorealistic, ultra-detailed",
  "law & llb": "A powerful legal visualization: ancient marble courthouse bathed in golden light with justice scales in the foreground, glowing law books floating in orbit, a gavel striking with light explosion, dramatic chiaroscuro lighting, deep mahogany and gold palette, ultra-detailed, cinematic",
};

function getImagePrompt(career: string): string {
  const lowerCareer = career.toLowerCase();
  for (const [key, prompt] of Object.entries(DOMAIN_IMAGE_PROMPTS)) {
    if (lowerCareer.includes(key) || key.split(" ").some(w => lowerCareer.includes(w))) {
      return prompt;
    }
  }
  return `A breathtaking futuristic visualization for ${career} career: glowing symbols and icons representing the field float in deep space, vibrant purple and cyan light trails connecting nodes, cinematic dark background with neon accents, ultra-detailed, 4K photorealistic illustration, inspiring and professional`;
}

router.post("/generate", async (req, res) => {
  req.setTimeout(90000);
  res.setTimeout(90000);

  const parseResult = GenerateRoadmapBody.safeParse(req.body);
  if (!parseResult.success) {
    res.status(400).json({ error: "Bad Request", message: parseResult.error.message });
    return;
  }

  const { interests, strengths, level, goal, certifications, domain } = parseResult.data;

  const systemPrompt = `You are an expert Indian career counselor. Generate a personalized JSON career roadmap for Indian students/professionals. Use ₹ and LPA for all salaries. Be specific, actionable, and reference Indian companies/exams.

Respond ONLY with a valid JSON object with these exact keys:
- career: string
- explanation: string (3-4 sentences, mention India market, user's interests/strengths)
- phases: array of 4 objects with {title: string, details: string[] (5 items)}
- skills: array of 5 objects with {name: string, explanation: string (2 sentences)}
- resources: array of 5 strings
- exams: array of 5 strings
- jobs: array of 5-6 strings (entry to senior progression)
- salary: string (format: "Entry: ₹X LPA → Mid: ₹Y LPA → Senior: ₹Z+ LPA")`;

  const userPrompt = `Career roadmap for:
Domain: ${domain}
Interests: ${interests}
Strengths: ${strengths || "not specified"}
Academic Level: ${level || "not specified"}
Goal: ${goal || "not specified"}
Certifications: ${certifications || "none"}

Generate a tailored roadmap mentioning the user's specific interests and India-specific opportunities.`;

  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-5-mini",
      max_completion_tokens: 4096,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt },
      ],
      response_format: { type: "json_object" },
    });

    const content = completion.choices[0]?.message?.content;
    if (!content) {
      res.status(500).json({ error: "AI Error", message: "No response from AI model" });
      return;
    }

    const roadmap = JSON.parse(content);
    res.json(roadmap);
  } catch (err: any) {
    req.log.error({ err }, "OpenAI roadmap generation failed");
    res.status(500).json({ error: "Generation Failed", message: err?.message ?? "Failed to generate roadmap" });
  }
});

router.get("/image", async (req, res) => {
  req.setTimeout(120000);
  res.setTimeout(120000);

  const career = (req.query.career as string) || (req.query.domain as string) || "General Career";

  try {
    const prompt = getImagePrompt(career);
    const imageBuffer = await generateImageBuffer(prompt, "1024x1024");
    const base64 = imageBuffer.toString("base64");
    res.json({ imageBase64: base64, mimeType: "image/png" });
  } catch (err: any) {
    req.log.error({ err }, "Image generation failed");
    res.status(500).json({ error: "Image Generation Failed", message: err?.message ?? "Failed to generate image" });
  }
});

export default router;
