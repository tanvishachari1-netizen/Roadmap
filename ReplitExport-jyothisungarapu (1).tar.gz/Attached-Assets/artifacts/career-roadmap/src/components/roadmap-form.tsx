import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { motion } from "framer-motion";
import {
  Sparkles,
  Briefcase,
  GraduationCap,
  Target,
  Award,
  Compass,
  Loader2,
  Brain,
  Zap,
} from "lucide-react";
import type { RoadmapRequest } from "@/hooks/use-roadmap";

const formSchema = z.object({
  interests: z.string().min(3, "Please describe your interests (min 3 chars)"),
  strengths: z.string().optional(),
  level: z.string().optional(),
  goal: z.string().optional(),
  certifications: z.string().optional(),
  domain: z.string().min(2, "Please specify a preferred domain"),
});

type FormValues = z.infer<typeof formSchema>;

interface RoadmapFormProps {
  onSubmit: (data: RoadmapRequest) => void;
  isLoading: boolean;
}

const exampleDomains = [
  "Software Engineering", "Data Science & AI", "UX/UI Design",
  "Digital Marketing", "Finance & CA", "Medicine / MBBS", "Law & LLB",
];

const fieldConfig = [
  {
    name: "domain" as const,
    label: "Preferred Domain / Career Field",
    placeholder: "e.g., Software Engineering, Data Science, UX Design, Finance...",
    icon: Compass,
    required: true,
    colSpan: 2,
    type: "input",
    hint: "Be specific — the AI tailors everything to your exact domain",
  },
  {
    name: "interests" as const,
    label: "Your Interests & Passions",
    placeholder: "What excites you? e.g., building apps, solving puzzles, analyzing data, writing code...",
    icon: Sparkles,
    required: true,
    colSpan: 2,
    type: "textarea",
    hint: "The more detail you give, the more personalized your roadmap",
  },
  {
    name: "strengths" as const,
    label: "Your Key Strengths",
    placeholder: "e.g., Logical thinking, communication, Python basics...",
    icon: Target,
    required: false,
    colSpan: 1,
    type: "input",
  },
  {
    name: "level" as const,
    label: "Academic Level",
    placeholder: "e.g., Class 12, B.Tech 2nd Year, Fresher...",
    icon: GraduationCap,
    required: false,
    colSpan: 1,
    type: "input",
  },
  {
    name: "goal" as const,
    label: "Career Goal",
    placeholder: "e.g., Work at Google, become a Senior DS, start a startup...",
    icon: Briefcase,
    required: false,
    colSpan: 1,
    type: "input",
  },
  {
    name: "certifications" as const,
    label: "Existing Certifications",
    placeholder: "e.g., AWS Cloud Practitioner, none...",
    icon: Award,
    required: false,
    colSpan: 1,
    type: "input",
  },
];

export function RoadmapForm({ onSubmit, isLoading }: RoadmapFormProps) {
  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: { interests: "", strengths: "", level: "", goal: "", certifications: "", domain: "" },
  });

  return (
    <div className="w-full max-w-3xl mx-auto">
      {/* Hero Section */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-center mb-12"
      >
        {/* AI Badge */}
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-primary/30 bg-primary/10 text-primary text-sm font-semibold mb-6"
        >
          <Zap className="w-3.5 h-3.5" />
          Powered by GPT-5 AI
          <span className="w-1.5 h-1.5 rounded-full bg-accent animate-pulse" />
        </motion.div>

        <h1 className="font-display text-5xl md:text-7xl font-bold text-foreground mb-4 leading-tight tracking-tight">
          Design Your
          <br />
          <span className="gradient-text">Dream Career</span>
        </h1>
        <p className="text-muted-foreground text-lg md:text-xl max-w-xl mx-auto leading-relaxed">
          Tell us about yourself. Our AI crafts a detailed, personalized roadmap with Indian salaries in LPA, real resources, and actionable phases.
        </p>
      </motion.div>

      {/* Quick Domain Chips */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="flex flex-wrap justify-center gap-2 mb-8"
      >
        {exampleDomains.map((d) => (
          <button
            key={d}
            type="button"
            onClick={() => setValue("domain", d)}
            className="px-3 py-1.5 rounded-full text-xs font-medium border border-border bg-card text-muted-foreground hover:border-primary/50 hover:text-primary hover:bg-primary/5 transition-all duration-200"
          >
            {d}
          </button>
        ))}
      </motion.div>

      {/* Form Card */}
      <motion.form
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        onSubmit={handleSubmit(onSubmit)}
        className="glass rounded-3xl p-6 md:p-8 border border-white/5 space-y-5"
      >
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {fieldConfig.map((field) => {
            const Icon = field.icon;
            return (
              <div
                key={field.name}
                className={`space-y-1.5 ${field.colSpan === 2 ? "col-span-1 md:col-span-2" : ""}`}
              >
                <label className="flex items-center gap-2 text-sm font-semibold text-foreground">
                  <Icon className="w-3.5 h-3.5 text-primary" />
                  {field.label}
                  {field.required && <span className="text-primary">*</span>}
                </label>

                {field.type === "textarea" ? (
                  <textarea
                    {...register(field.name)}
                    placeholder={field.placeholder}
                    rows={3}
                    disabled={isLoading}
                    className="w-full px-4 py-3 rounded-xl bg-secondary/50 border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 focus:ring-2 focus:ring-primary/15 transition-all duration-200 resize-none text-sm"
                  />
                ) : (
                  <input
                    {...register(field.name)}
                    placeholder={field.placeholder}
                    disabled={isLoading}
                    className="w-full px-4 py-3 rounded-xl bg-secondary/50 border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 focus:ring-2 focus:ring-primary/15 transition-all duration-200 text-sm"
                  />
                )}

                {field.hint && (
                  <p className="text-xs text-muted-foreground/70 pl-1">{field.hint}</p>
                )}
                {errors[field.name] && (
                  <p className="text-destructive text-xs mt-1">{errors[field.name]?.message}</p>
                )}
              </div>
            );
          })}
        </div>

        {/* Submit Button */}
        <div className="pt-2">
          <button
            type="submit"
            disabled={isLoading}
            className="w-full relative flex items-center justify-center gap-3 px-8 py-4 rounded-2xl font-bold text-base text-white overflow-hidden transition-all duration-300 disabled:opacity-60 disabled:cursor-not-allowed group pulse-glow"
            style={{
              background: isLoading
                ? "linear-gradient(135deg, hsl(258 90% 55%), hsl(186 100% 40%))"
                : "linear-gradient(135deg, hsl(258 90% 66%), hsl(186 100% 50%))",
            }}
          >
            <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
              style={{ background: "linear-gradient(135deg, hsl(258 90% 72%), hsl(186 100% 56%))" }}
            />
            <span className="relative flex items-center gap-3">
              {isLoading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>AI is generating your roadmap...</span>
                </>
              ) : (
                <>
                  <Brain className="w-5 h-5" />
                  <span>Generate My Career Roadmap</span>
                  <Sparkles className="w-4 h-4 opacity-80" />
                </>
              )}
            </span>
          </button>

          {isLoading && (
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center text-xs text-muted-foreground mt-3"
            >
              GPT-5 is crafting your personalized roadmap... this takes 10–20 seconds
            </motion.p>
          )}
        </div>
      </motion.form>

      {/* Bottom trust badges */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.6 }}
        className="flex items-center justify-center gap-6 mt-8 text-xs text-muted-foreground"
      >
        <span className="flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
          Real AI, not templates
        </span>
        <span className="flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-primary" />
          Indian salary (₹ LPA)
        </span>
        <span className="flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-accent" />
          Any career domain
        </span>
      </motion.div>
    </div>
  );
}
