import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import {
  Briefcase,
  BookOpen,
  Award,
  TrendingUp,
  CheckCircle2,
  Lightbulb,
  RotateCcw,
  IndianRupee,
  ArrowRight,
  GraduationCap,
  Target,
  Zap,
  Star,
  MapPin,
  ImageIcon,
} from "lucide-react";
import type { RoadmapResponse } from "@/hooks/use-roadmap";

interface RoadmapResultProps {
  data: RoadmapResponse;
  onReset: () => void;
}

const container = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.07 } },
};

const item = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.45, ease: "easeOut" } },
};

const phaseClasses = ["phase-card-1", "phase-card-2", "phase-card-3", "phase-card-4"];
const phaseDotClasses = ["phase-dot-1", "phase-dot-2", "phase-dot-3", "phase-dot-4"];
const phaseTextClasses = ["phase-text-1", "phase-text-2", "phase-text-3", "phase-text-4"];
const phaseCheckClasses = ["phase-check-1", "phase-check-2", "phase-check-3", "phase-check-4"];

function useDomainImage(career: string) {
  const [imageBase64, setImageBase64] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setImageBase64(null);

    const baseUrl = import.meta.env.BASE_URL?.replace(/\/$/, "") || "";
    const encodedCareer = encodeURIComponent(career);

    fetch(`${baseUrl}/api/roadmap/image?career=${encodedCareer}`)
      .then((r) => r.json())
      .then((data) => {
        if (!cancelled && data.imageBase64) {
          setImageBase64(data.imageBase64);
        }
      })
      .catch(() => {})
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    return () => { cancelled = true; };
  }, [career]);

  return { imageBase64, loading };
}

export function RoadmapResult({ data, onReset }: RoadmapResultProps) {
  const { imageBase64, loading: imageLoading } = useDomainImage(data.career);

  return (
    <motion.div
      className="w-full max-w-6xl mx-auto pb-24 space-y-8"
      variants={container}
      initial="hidden"
      animate="visible"
    >
      {/* ── HERO BANNER with AI-generated illustration ── */}
      <motion.div variants={item} className="relative rounded-3xl overflow-hidden border border-white/5">

        {/* AI-generated domain illustration */}
        <div className="relative h-52 md:h-64 overflow-hidden">
          {imageLoading ? (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-3"
              style={{ background: "linear-gradient(135deg, hsl(230 25% 12%), hsl(258 30% 15%))" }}>
              <div className="relative">
                <div className="w-12 h-12 rounded-2xl border-2 border-primary/30 border-t-primary animate-spin" />
                <ImageIcon className="w-5 h-5 text-primary/60 absolute inset-0 m-auto" />
              </div>
              <span className="text-xs text-muted-foreground animate-pulse">Generating domain illustration…</span>
            </div>
          ) : imageBase64 ? (
            <motion.img
              src={`data:image/png;base64,${imageBase64}`}
              alt={`${data.career} career illustration`}
              className="w-full h-full object-cover"
              initial={{ opacity: 0, scale: 1.05 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
            />
          ) : (
            /* Fallback gradient if image fails */
            <div className="absolute inset-0"
              style={{ background: "linear-gradient(135deg, hsl(258 60% 20%), hsl(186 60% 15%), hsl(230 25% 10%))" }} />
          )}

          {/* Overlay gradient at the bottom for smooth blend */}
          <div className="absolute inset-0 pointer-events-none"
            style={{ background: "linear-gradient(to bottom, transparent 40%, hsl(230 25% 7%) 100%)" }} />

          {/* Overlay gradient at top for navbar readability */}
          <div className="absolute inset-0 pointer-events-none"
            style={{ background: "linear-gradient(to bottom, hsl(230 25% 7% / 0.5) 0%, transparent 30%)" }} />
        </div>

        {/* Gradient mesh background behind text */}
        <div className="absolute bottom-0 left-0 right-0 pointer-events-none">
          <div className="absolute bottom-0 left-1/4 w-72 h-72 rounded-full blur-3xl opacity-20"
            style={{ background: "hsl(258 90% 66%)" }} />
          <div className="absolute bottom-0 right-1/4 w-64 h-64 rounded-full blur-3xl opacity-15"
            style={{ background: "hsl(186 100% 50%)" }} />
        </div>

        <div className="relative z-10 glass p-8 md:p-12 -mt-8 rounded-b-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-primary/30 bg-primary/10 text-primary text-xs font-semibold mb-5">
            <Zap className="w-3 h-3" />
            AI-Generated Personalized Roadmap
          </div>

          <h1 className="font-display text-4xl md:text-6xl font-bold mb-4 leading-tight">
            <span className="gradient-text">{data.career}</span>
          </h1>

          <p className="text-base md:text-lg text-muted-foreground leading-relaxed max-w-4xl mb-8">
            {data.explanation}
          </p>

          {/* Salary highlight */}
          <div className="inline-flex items-start gap-4 px-6 py-4 rounded-2xl border border-emerald-500/20 bg-emerald-500/5">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
              style={{ background: "hsl(141 70% 40% / 0.15)" }}>
              <IndianRupee className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <p className="text-xs text-emerald-400/60 font-semibold uppercase tracking-widest mb-1">
                India Salary Range (LPA)
              </p>
              <p className="text-base font-bold text-emerald-300">{data.salary}</p>
            </div>
          </div>
        </div>
      </motion.div>

      {/* ── PHASES GRID ── */}
      <motion.div variants={item}>
        <SectionHeader icon={TrendingUp} title="Your 4-Phase Career Roadmap" subtitle="Detailed, actionable phases from beginner to expert" />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-5">
          {data.phases.map((phase, i) => (
            <motion.div
              key={i}
              variants={item}
              className={`rounded-2xl border p-6 ${phaseClasses[i % 4]}`}
            >
              <div className="flex items-center gap-3 mb-4">
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 text-white text-sm font-bold ${phaseDotClasses[i % 4]}`}>
                  {i + 1}
                </div>
                <h3 className={`font-display font-bold text-sm leading-snug ${phaseTextClasses[i % 4]}`}>
                  {phase.title}
                </h3>
              </div>

              <ul className="space-y-2.5">
                {phase.details.map((d, j) => (
                  <li key={j} className="flex items-start gap-2.5 text-sm text-foreground/80 leading-snug">
                    <CheckCircle2 className={`w-4 h-4 shrink-0 mt-0.5 ${phaseCheckClasses[i % 4]}`} />
                    <span>{d}</span>
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* ── JOB PROGRESSION ── */}
      <motion.div variants={item} className="glass rounded-3xl border border-white/5 p-6 md:p-8">
        <SectionHeader icon={Briefcase} title="Career Progression Path" subtitle="Job titles you will grow through — from fresher to expert" />

        <div className="flex flex-wrap items-center gap-2 mt-6">
          {data.jobs.map((job, i) => (
            <div key={i} className="flex items-center gap-2">
              <div className={`px-4 py-2 rounded-xl text-sm font-semibold border transition-all ${
                i === 0
                  ? "border-border bg-secondary text-muted-foreground"
                  : i === data.jobs.length - 1
                  ? "border-primary/40 bg-primary/10 text-primary"
                  : "border-border/60 bg-card text-foreground/80"
              }`}>
                {i === data.jobs.length - 1 && <Star className="w-3 h-3 inline mr-1.5 text-primary" />}
                {job}
              </div>
              {i < data.jobs.length - 1 && (
                <ArrowRight className="w-4 h-4 text-muted-foreground/30 shrink-0" />
              )}
            </div>
          ))}
        </div>
      </motion.div>

      {/* ── SKILLS + RESOURCES + EXAMS (3 columns) ── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">

        {/* Skills */}
        <motion.div variants={item} className="glass rounded-3xl border border-white/5 p-6">
          <div className="flex items-center gap-2.5 mb-5">
            <div className="w-8 h-8 rounded-xl bg-primary/10 flex items-center justify-center">
              <Lightbulb className="w-4 h-4 text-primary" />
            </div>
            <h2 className="font-display font-bold text-base text-foreground">Essential Skills</h2>
          </div>

          <div className="space-y-3">
            {data.skills.map((s, i) => (
              <div key={i} className="p-4 rounded-xl border border-border/50 bg-secondary/30 hover:border-primary/30 transition-colors">
                <div className="flex items-center gap-2 mb-1.5">
                  <Target className="w-3.5 h-3.5 text-primary shrink-0" />
                  <h4 className="font-semibold text-sm text-foreground">{s.name}</h4>
                </div>
                <p className="text-xs text-muted-foreground leading-relaxed">{s.explanation}</p>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Resources */}
        <motion.div variants={item} className="glass rounded-3xl border border-white/5 p-6">
          <div className="flex items-center gap-2.5 mb-5">
            <div className="w-8 h-8 rounded-xl bg-accent/10 flex items-center justify-center">
              <BookOpen className="w-4 h-4 text-accent" />
            </div>
            <h2 className="font-display font-bold text-base text-foreground">Best Resources</h2>
          </div>

          <ul className="space-y-3">
            {data.resources.map((r, i) => (
              <li key={i} className="flex items-start gap-3 p-3 rounded-xl border border-border/40 bg-secondary/20 hover:border-accent/20 transition-colors">
                <div className="w-6 h-6 rounded-lg bg-accent/10 flex items-center justify-center shrink-0 mt-0.5">
                  <span className="text-xs font-bold text-accent">{i + 1}</span>
                </div>
                <span className="text-sm text-foreground/85 leading-snug">{r}</span>
              </li>
            ))}
          </ul>
        </motion.div>

        {/* Exams */}
        <motion.div variants={item} className="glass rounded-3xl border border-white/5 p-6">
          <div className="flex items-center gap-2.5 mb-5">
            <div className="w-8 h-8 rounded-xl bg-yellow-500/10 flex items-center justify-center">
              <GraduationCap className="w-4 h-4 text-yellow-400" />
            </div>
            <h2 className="font-display font-bold text-base text-foreground">Key Exams & Certs</h2>
          </div>

          <ul className="space-y-3">
            {data.exams.map((e, i) => (
              <li key={i} className="flex items-center gap-3 p-3 rounded-xl border border-border/40 bg-secondary/20 hover:border-yellow-500/20 transition-colors">
                <div className="w-7 h-7 rounded-lg bg-yellow-500/10 flex items-center justify-center shrink-0">
                  <Award className="w-3.5 h-3.5 text-yellow-400" />
                </div>
                <span className="text-sm font-medium text-foreground/85">{e}</span>
              </li>
            ))}
          </ul>
        </motion.div>
      </div>

      {/* ── FOOTER ── */}
      <motion.div
        variants={item}
        className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-6 border-t border-border/30"
      >
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <MapPin className="w-3.5 h-3.5 text-primary" />
          <span>Roadmap tailored for the <strong className="text-foreground/70">Indian job market</strong> — adjust pace to your schedule</span>
        </div>
        <button
          onClick={onReset}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold border border-border bg-secondary text-foreground hover:border-primary/50 hover:text-primary transition-all duration-200 whitespace-nowrap"
        >
          <RotateCcw className="w-4 h-4" />
          Generate Another Roadmap
        </button>
      </motion.div>
    </motion.div>
  );
}

function SectionHeader({
  icon: Icon,
  title,
  subtitle,
}: {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  subtitle: string;
}) {
  return (
    <div className="flex items-start gap-3">
      <div className="w-10 h-10 rounded-2xl bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
        <Icon className="w-5 h-5 text-primary" />
      </div>
      <div>
        <h2 className="font-display font-bold text-xl text-foreground">{title}</h2>
        <p className="text-sm text-muted-foreground mt-0.5">{subtitle}</p>
      </div>
    </div>
  );
}
