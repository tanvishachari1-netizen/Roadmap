import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Brain, Sparkles, Users } from "lucide-react";
import { useGenerateRoadmap } from "@/hooks/use-roadmap";
import { RoadmapForm } from "@/components/roadmap-form";
import { RoadmapResult } from "@/components/roadmap-result";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import type { RoadmapRequest } from "@/hooks/use-roadmap";

export default function Home() {
  const { toast } = useToast();
  const generateMutation = useGenerateRoadmap();
  const [result, setResult] = useState<any>(null);
  const [, setLocation] = useLocation();

  const handleSubmit = (data: RoadmapRequest) => {
    generateMutation.mutate({ data }, {
      onSuccess: (res) => {
        setResult(res);
        window.scrollTo({ top: 0, behavior: "smooth" });
      },
      onError: (error: any) => {
        toast({
          title: "Generation Failed",
          description: error?.message || "There was an error generating your roadmap. Please try again.",
          variant: "destructive",
        });
      },
    });
  };

  const handleReset = () => {
    setResult(null);
    generateMutation.reset();
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="min-h-screen bg-background relative selection:bg-primary/20 selection:text-primary">
      {/* Ambient background orbs */}
      <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full blur-3xl opacity-10"
          style={{ background: "hsl(258 90% 66%)" }} />
        <div className="absolute bottom-1/3 right-1/4 w-80 h-80 rounded-full blur-3xl opacity-8"
          style={{ background: "hsl(186 100% 50%)" }} />
        <div className="absolute top-2/3 left-1/2 w-64 h-64 rounded-full blur-3xl opacity-6"
          style={{ background: "hsl(30 100% 60%)" }} />
      </div>
      {/* Navbar */}
      <nav className="relative z-50 sticky top-0 border-b border-white/5 bg-background/80 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-14 flex items-center justify-between">
          <button
            onClick={handleReset}
            className="flex items-center gap-2.5 group"
          >
            <div className="w-8 h-8 rounded-xl flex items-center justify-center"
              style={{ background: "linear-gradient(135deg, hsl(258 90% 66%), hsl(186 100% 50%))" }}>
              <Brain className="w-4 h-4 text-white" />
            </div>
            <span className="font-display font-bold text-base text-foreground">CAREER CHOICE AI</span>
          </button>

          <div className="flex items-center gap-4">
            <button
              onClick={() => setLocation("/team")}
              className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors px-3 py-1.5 rounded-lg hover:bg-white/5"
            >
              <Users className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Meet the Team</span>
            </button>
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Sparkles className="w-3.5 h-3.5 text-primary" />
              <span className="hidden sm:inline">GPT-5 Powered · Any Career · India Salaries</span>
            </div>
          </div>
        </div>
      </nav>
      {/* Main Content */}
      <main className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
        <AnimatePresence mode="wait">
          {!result ? (
            <motion.div
              key="form"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.02, filter: "blur(8px)" }}
              transition={{ duration: 0.35 }}
            >
              <RoadmapForm onSubmit={handleSubmit} isLoading={generateMutation.isPending} />
            </motion.div>
          ) : (
            <motion.div
              key="result"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.45 }}
            >
              <RoadmapResult data={result} onReset={handleReset} />
            </motion.div>
          )}
        </AnimatePresence>
      </main>
      {/* Footer */}
      <footer className="relative z-10 border-t border-white/5 py-6 mt-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-muted-foreground">
          <span>PathFinder AI — Career Roadmap Generator powered by GPT-5</span>
          <span className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            Real AI · Tailored for India · ₹ LPA Salaries
          </span>
        </div>
      </footer>
    </div>
  );
}
