import { motion } from "framer-motion";
import { Brain, Mail, Phone, Users, Code2, Sparkles, ArrowLeft, Github, Linkedin } from "lucide-react";
import { useLocation } from "wouter";

const developers = [
  {
    name: "Tulugu Dilleswara Rao",
    role: "Full Stack Developer",
    email: "tulugudilleswar@gmail.com",
    phone: "7842338311",
    avatar: "TD",
    gradient: "from-violet-600 via-purple-600 to-indigo-600",
    glowColor: "hsl(258 90% 66%)",
    tag: "Backend & AI Integration",
    description: "Architected the AI-powered roadmap engine and Express backend, integrating GPT-5 for personalized career generation.",
  },
  {
    name: "Srungarapu Tanvish Achari",
    role: "Frontend Engineer",
    email: "tanvishaschari1@gmail.com",
    phone: "7330989792",
    avatar: "ST",
    gradient: "from-cyan-500 via-teal-500 to-blue-600",
    glowColor: "hsl(186 100% 50%)",
    tag: "UI/UX & Animations",
    description: "Crafted the immersive dark-themed UI with glassmorphism, framer-motion animations, and the responsive design system.",
  },
  {
    name: "Vaddepally Santhosh",
    role: "AI & Data Engineer",
    email: "vaddepallysanthosh7@gmail.com",
    phone: "8247643687",
    avatar: "VS",
    gradient: "from-orange-500 via-rose-500 to-pink-600",
    glowColor: "hsl(30 100% 60%)",
    tag: "Prompt Engineering",
    description: "Designed the intelligent prompt engineering pipeline, ensuring accurate India-market roadmaps with real ₹ LPA salary data.",
  },
  {
    name: "Shasaleti Devendar",
    role: "Systems Architect",
    email: "shasaletidevendar@gmail.com",
    phone: "9391686719",
    avatar: "SD",
    gradient: "from-emerald-500 via-green-500 to-teal-600",
    glowColor: "hsl(141 70% 50%)",
    tag: "API Design & DevOps",
    description: "Designed the OpenAPI spec, codegen workflow, and deployment architecture that powers the PathFinder AI platform.",
  },
];

const container = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.12 } },
};

const cardItem = {
  hidden: { opacity: 0, y: 40, scale: 0.95 },
  visible: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.55, ease: "easeOut" } },
};

export default function Team() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-background relative selection:bg-primary/20 selection:text-primary overflow-x-hidden">

      {/* Ambient orbs */}
      <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden">
        <div className="absolute top-0 left-0 w-[600px] h-[600px] rounded-full blur-3xl opacity-8"
          style={{ background: "hsl(258 90% 66%)", transform: "translate(-30%, -30%)" }} />
        <div className="absolute bottom-0 right-0 w-[500px] h-[500px] rounded-full blur-3xl opacity-8"
          style={{ background: "hsl(186 100% 50%)", transform: "translate(30%, 30%)" }} />
        <div className="absolute top-1/2 left-1/2 w-96 h-96 rounded-full blur-3xl opacity-5"
          style={{ background: "hsl(30 100% 60%)", transform: "translate(-50%, -50%)" }} />
      </div>

      {/* Navbar */}
      <nav className="relative z-50 sticky top-0 border-b border-white/5 bg-background/80 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-14 flex items-center justify-between">
          <button
            onClick={() => setLocation("/")}
            className="flex items-center gap-2.5 group"
          >
            <div className="w-8 h-8 rounded-xl flex items-center justify-center"
              style={{ background: "linear-gradient(135deg, hsl(258 90% 66%), hsl(186 100% 50%))" }}>
              <Brain className="w-4 h-4 text-white" />
            </div>
            <span className="font-display font-bold text-base text-foreground">PathFinder AI</span>
          </button>

          <button
            onClick={() => setLocation("/")}
            className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            Back to App
          </button>
        </div>
      </nav>

      <main className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24">

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-20"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-primary/30 bg-primary/10 text-primary text-xs font-semibold mb-8">
            <Users className="w-3.5 h-3.5" />
            The Team Behind PathFinder AI
          </div>

          <h1 className="font-display text-5xl md:text-7xl font-bold leading-tight mb-6">
            <span className="text-foreground">Meet the</span>
            <br />
            <span className="gradient-text">Developers</span>
          </h1>

          <p className="text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            Four passionate engineers from India who built PathFinder AI to help students and professionals 
            navigate their career journeys with the power of AI.
          </p>

          {/* Stats row */}
          <div className="flex flex-wrap justify-center gap-8 mt-12">
            {[
              { label: "Team Members", value: "4" },
              { label: "Careers Supported", value: "50+" },
              { label: "AI Powered", value: "GPT-5" },
              { label: "Made in", value: "India 🇮🇳" },
            ].map((stat, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 + i * 0.1 }}
                className="text-center"
              >
                <div className="font-display text-3xl font-bold gradient-text">{stat.value}</div>
                <div className="text-xs text-muted-foreground mt-1">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Developer Cards */}
        <motion.div
          variants={container}
          initial="hidden"
          animate="visible"
          className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8"
        >
          {developers.map((dev, i) => (
            <motion.div
              key={i}
              variants={cardItem}
              className="group relative rounded-3xl border border-white/8 bg-card/40 backdrop-blur-sm overflow-hidden hover:border-white/15 transition-all duration-500"
            >
              {/* Card glow on hover */}
              <div
                className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"
                style={{ background: `radial-gradient(ellipse at top left, ${dev.glowColor}15 0%, transparent 60%)` }}
              />

              {/* Top gradient bar */}
              <div className={`h-1 w-full bg-gradient-to-r ${dev.gradient}`} />

              <div className="p-8">
                {/* Avatar + Name row */}
                <div className="flex items-start gap-5 mb-6">
                  {/* Avatar */}
                  <div className="relative shrink-0">
                    <div
                      className={`w-18 h-18 w-[72px] h-[72px] rounded-2xl flex items-center justify-center bg-gradient-to-br ${dev.gradient} shadow-lg`}
                    >
                      <span className="font-display font-bold text-2xl text-white">{dev.avatar}</span>
                    </div>
                    <div
                      className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full border-2 border-background flex items-center justify-center"
                      style={{ background: dev.glowColor }}
                    >
                      <Code2 className="w-2.5 h-2.5 text-white" />
                    </div>
                  </div>

                  {/* Name & role */}
                  <div className="flex-1 min-w-0">
                    <h2 className="font-display font-bold text-xl text-foreground leading-tight">{dev.name}</h2>
                    <p className={`text-sm font-semibold mt-1 bg-gradient-to-r ${dev.gradient} bg-clip-text text-transparent`}>
                      {dev.role}
                    </p>
                    <div className="inline-flex items-center gap-1.5 mt-2 px-3 py-1 rounded-full border border-white/10 bg-white/5 text-xs text-muted-foreground">
                      <Sparkles className="w-2.5 h-2.5" />
                      {dev.tag}
                    </div>
                  </div>
                </div>

                {/* Description */}
                <p className="text-sm text-muted-foreground leading-relaxed mb-6 border-l-2 border-white/10 pl-4">
                  {dev.description}
                </p>

                {/* Contact info */}
                <div className="space-y-3">
                  <a
                    href={`mailto:${dev.email}`}
                    className="flex items-center gap-3 px-4 py-3 rounded-xl border border-white/8 bg-white/3 hover:border-white/15 hover:bg-white/6 transition-all group/link"
                  >
                    <div
                      className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
                      style={{ background: `${dev.glowColor}20` }}
                    >
                      <Mail className="w-4 h-4" style={{ color: dev.glowColor }} />
                    </div>
                    <span className="text-sm text-foreground/80 group-hover/link:text-foreground transition-colors truncate font-mono">
                      {dev.email}
                    </span>
                  </a>

                  <a
                    href={`tel:+91${dev.phone}`}
                    className="flex items-center gap-3 px-4 py-3 rounded-xl border border-white/8 bg-white/3 hover:border-white/15 hover:bg-white/6 transition-all group/link"
                  >
                    <div
                      className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
                      style={{ background: `${dev.glowColor}20` }}
                    >
                      <Phone className="w-4 h-4" style={{ color: dev.glowColor }} />
                    </div>
                    <span className="text-sm text-foreground/80 group-hover/link:text-foreground transition-colors font-mono">
                      +91 {dev.phone}
                    </span>
                  </a>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8, duration: 0.6 }}
          className="mt-20 text-center"
        >
          <div className="glass rounded-3xl border border-white/8 p-10 max-w-2xl mx-auto">
            <div className="w-14 h-14 rounded-2xl mx-auto mb-5 flex items-center justify-center"
              style={{ background: "linear-gradient(135deg, hsl(258 90% 66%), hsl(186 100% 50%))" }}>
              <Brain className="w-7 h-7 text-white" />
            </div>
            <h3 className="font-display text-2xl font-bold text-foreground mb-3">Built with passion for India</h3>
            <p className="text-sm text-muted-foreground leading-relaxed mb-6">
              PathFinder AI was built to democratize career guidance for every Indian student and professional — 
              powered by cutting-edge AI and designed with love.
            </p>
            <button
              onClick={() => setLocation("/")}
              className="inline-flex items-center gap-2 px-7 py-3 rounded-xl text-sm font-semibold text-white transition-all duration-200 hover:opacity-90 hover:scale-105"
              style={{ background: "linear-gradient(135deg, hsl(258 90% 66%), hsl(186 100% 50%))" }}
            >
              <Sparkles className="w-4 h-4" />
              Try PathFinder AI
            </button>
          </div>
        </motion.div>
      </main>

      {/* Footer */}
      <footer className="relative z-10 border-t border-white/5 py-6 mt-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-muted-foreground">
          <span>PathFinder AI — Crafted with ❤️ by Team PathFinder</span>
          <span className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            Made in India · Powered by GPT-5
          </span>
        </div>
      </footer>
    </div>
  );
}
