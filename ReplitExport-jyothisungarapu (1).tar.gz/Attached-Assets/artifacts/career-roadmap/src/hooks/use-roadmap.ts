import { useGenerateRoadmap as useGeneratedRoadmap } from "@workspace/api-client-react";
import type { RoadmapRequest, RoadmapResponse, ErrorResponse } from "@workspace/api-client-react/src/generated/api.schemas";

// Re-exporting the hook to keep a clean interface and allow for local overrides if needed
export function useGenerateRoadmap() {
  return useGeneratedRoadmap();
}

export type { RoadmapRequest, RoadmapResponse, ErrorResponse };
